from pyspark.sql import SparkSession, functions as F
spark = SparkSession.builder.appName("s3oc-normalize").getOrCreate()
df = spark.read.json("data/bronze/telemetry/*")
# Example: Celsius -> Kelvin
df2 = df.withColumn("measures", F.expr("""
transform(measures, m -> case when m.unit='C' then named_struct('name', m.name, 'value', m.value+273.15, 'unit', 'K', 'method', m.method) else m end)
"""))
df2.write.mode("append").json("data/silver/telemetry/")