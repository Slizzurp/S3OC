package main
import ("encoding/json"; "net/http"; "time")
type Evidence struct{ Facts []map[string]any `json:"facts"`; Provenance []string `json:"prov"`}
func curate(w http.ResponseWriter, r *http.Request){
  var in []map[string]any; json.NewDecoder(r.Body).Decode(&in)
  ev := Evidence{Facts: in, Provenance: []string{"s3oc:ingest"}}
  w.Header().Set("Content-Type","application/json")
  json.NewEncoder(w).Encode(map[string]any{"evidence": ev, "ts": time.Now().Unix()})
}
func main(){ http.HandleFunc("/curate", curate); http.ListenAndServe(":8084", nil) }