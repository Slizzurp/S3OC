from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uuid, yaml, time

app = FastAPI(title="S3OC Conductor")

class ExecuteReq(BaseModel):
    name: str
    params: dict = {}

RUNS = {}

def load_score(name: str) -> dict:
    with open(f"codex/scores/{name}.yaml", "r") as f:
        return yaml.safe_load(f)

@app.post("/scores/execute")
def execute(req: ExecuteReq):
    run_id = str(uuid.uuid4())
    score = load_score(req.name)
    RUNS[run_id] = {"status": "running", "started": time.time(), "score": score}
    # TODO: dispatch to sections via message bus
    return {"run_id": run_id}

@app.get("/runs/{run_id}/status")
def status(run_id: str):
    run = RUNS.get(run_id)
    if not run:
        raise HTTPException(404, "run not found")
    return run