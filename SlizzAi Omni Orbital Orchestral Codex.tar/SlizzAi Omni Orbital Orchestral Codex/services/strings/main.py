from fastapi import FastAPI, Body
import time, hashlib

app = FastAPI(title="S3OC Strings")

@app.post("/ingest")
def ingest(batch: list[dict] = Body(...)):
    # TODO: checkpointing, backpressure
    h = hashlib.sha256(str(batch[0]).encode()).hexdigest() if batch else ""
    return {"received": len(batch), "first_hash": h, "ts": time.time()}