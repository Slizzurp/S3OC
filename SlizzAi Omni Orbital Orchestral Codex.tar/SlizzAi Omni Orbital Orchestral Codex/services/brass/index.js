import express from "express";
import fetch from "node-fetch";
const app = express(); app.use(express.json());

app.post("/connect", async (req, res) => {
  const { endpoints } = req.body;
  const results = await Promise.all(endpoints.map(async (u) => {
    const r = await fetch(u); return { url: u, status: r.status };
  }));
  res.json({ results });
});

app.listen(8082, () => console.log("Brass on 8082"));