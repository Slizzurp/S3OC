import json, time, uuid, random
def obs():
  return {
    "id": str(uuid.uuid4()),
    "domain": "telemetry",
    "timestamp": int(time.time()*1000),
    "subject": {"id": "sat-7", "type": "satellite"},
    "measures": [{"name":"temp","value": random.uniform(-10,35),"unit":"C","method":"direct"}],
    "confidence": 0.99,
    "flags": [],
    "provenance": {"source":"sim", "method":"synth", "signature":"dev", "collected_at": int(time.time()*1000)}
  }
if __name__ == "__main__":
  for _ in range(10):
    print(json.dumps(obs())); time.sleep(0.2)