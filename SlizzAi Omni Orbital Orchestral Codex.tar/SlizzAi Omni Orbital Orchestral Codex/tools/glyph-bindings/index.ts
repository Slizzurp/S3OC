export type Glyph = "RedBaton" | "CollisionSpiral" | "BurnWindow" | "RelayShift" | "ThermalVeil" | "FinaleDebrisDance";

export const Bindings: Record<Glyph, { sections: string[]; action: string; outputs: string[] }> = {
  RedBaton: { sections: ["conductor","brass","strings"], action: "initiate_encore", outputs: ["event_context","section_budgets","channel_map"] },
  CollisionSpiral: { sections: ["harps","choir"], action: "fetch_and_normalize_vectors", outputs: ["collision_map","delta_v_thresholds"] },
  BurnWindow: { sections: ["harps","strings"], action: "calculate_burn_window", outputs: ["burn_plan","execution_timer"] },
  RelayShift: { sections: ["brass","choir"], action: "switch_relay_path", outputs: ["relay_manifest","link_status"] },
  ThermalVeil: { sections: ["harps","choir"], action: "forecast_thermal_load", outputs: ["thermal_chart","radiator_log"] },
  FinaleDebrisDance: { sections: ["conductor","all"], action: "archive_and_mint_finale", outputs: ["archived_package","lineage_entry"] }
};